# WOYO Match

Site web mobile-first (installable sur téléphone) qui met en relation les **propriétaires de voitures** et les **chauffeurs VTC** à Abidjan, avec des contrats durables pour réduire la précarité des chauffeurs et le turn-over côté propriétaires.

## Contenu du dépôt
- `site/` : le site (HTML/CSS/JS, sans installation). Actuellement un prototype avec données de démonstration.
- `docs/cahier-des-charges.md` : cahier des charges du MVP.
- `.github/workflows/pages.yml` : publie automatiquement `site/` sur GitHub Pages.

## Mettre le site en ligne (gratuit)
1. Créez un dépôt sur github.com et déposez tous ces fichiers (branche `main`).
2. Dans le dépôt : **Settings > Pages > Source : GitHub Actions**.
3. Après 1 à 2 minutes, l'adresse du site apparaît dans l'onglet **Actions**.

## Feuille de route
1. Prototype (fait) : offres, candidats, compatibilité, publication de voiture.
2. Comptes et base de données (inscription par SMS, profils réels).
3. Vérification CNI/permis, contrat numérique, évaluations croisées.
4. Paiement mobile money (Orange, MTN, Moov, Wave) et forfaits propriétaires.
